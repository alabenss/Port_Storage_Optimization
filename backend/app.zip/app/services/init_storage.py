from sqlalchemy.orm import Session

from app.models.storage_zone import StorageZone
from app.models.storage_position import StoragePosition


def initialize_storage(db: Session):

    existing = db.query(StorageZone).count()

    if existing > 0:
        return {
            "status": "ALREADY_INITIALIZED",
            "zones": existing
        }

    # =====================================================
    # STORAGE ZONES
    # =====================================================

    zone_definitions = [

        {
            "code": "VEH-01",
            "name": "Vehicle Yard 01",
            "zone_type": "VEHICLE_YARD",
            "description": "Dedicated storage area for individual vehicles.",
            "capacity": 40,
            "priority_score": 0.90,
            "map_x": 25,
            "map_y": 35
        },

        {
            "code": "CONT-01",
            "name": "Container Yard 01",
            "zone_type": "CONTAINER_YARD",
            "description": "Dedicated storage area for containers.",
            "capacity": 24,
            "priority_score": 0.85,
            "map_x": 60,
            "map_y": 25
        },

        {
            "code": "PACK-01",
            "name": "Package Storage Area",
            "zone_type": "PACKAGE_AREA",
            "description": "Stackable miscellaneous packaged cargo.",
            "capacity": 12,
            "priority_score": 0.75,
            "map_x": 70,
            "map_y": 65
        },

        {
            "code": "COIL-01",
            "name": "Coil Storage Area",
            "zone_type": "COIL_AREA",
            "description": "Ground-level non-stackable coil storage.",
            "capacity": 16,
            "priority_score": 0.80,
            "map_x": 45,
            "map_y": 70
        },

        {
            "code": "BULK-01",
            "name": "Bulk Silo Area",
            "zone_type": "BULK_SILO_AREA",
            "description": "Bulk cargo storage in dedicated silos.",
            "capacity": 4,
            "priority_score": 0.80,
            "map_x": 15,
            "map_y": 20
        }

    ]

    zones = {}

    for definition in zone_definitions:

        zone = StorageZone(
            code=definition["code"],
            name=definition["name"],
            zone_type=definition["zone_type"],
            description=definition["description"],
            capacity=definition["capacity"],
            priority_score=definition["priority_score"],
            active=True,
            map_x=definition["map_x"],
            map_y=definition["map_y"]
        )

        db.add(zone)
        db.flush()

        zones[definition["code"]] = zone

    # =====================================================
    # VEHICLE YARD
    # =====================================================

    vehicle_zone = zones["VEH-01"]

    position_counter = 1

    for row_index, row_code in enumerate(
        ["A", "B", "C", "D"],
        start=1
    ):

        for slot in range(1, 11):

            position = StoragePosition(
                zone_id=vehicle_zone.id,
                position_code=(
                    f"VEH-{row_code}-{slot:03}"
                ),
                position_type="VEHICLE_SLOT",
                row_code=row_code,
                slot_number=slot,
                level=1,
                max_stack_level=1,
                max_weight=5000,
                current_weight=0,
                occupied=False,
                active=True,
                accessibility_score=round(
                    1.0 - ((position_counter - 1) * 0.01),
                    2
                ),
                x_coordinate=10 + (slot * 5),
                y_coordinate=10 + (row_index * 6),
                length=6,
                width=3
            )

            db.add(position)

            position_counter += 1

    # =====================================================
    # CONTAINER YARD
    # =====================================================

    container_zone = zones["CONT-01"]

    for row_index, row_code in enumerate(
        ["A", "B", "C"],
        start=1
    ):

        for slot in range(1, 9):

            position = StoragePosition(
                zone_id=container_zone.id,
                position_code=(
                    f"CONT-{row_code}-{slot:03}"
                ),
                position_type="CONTAINER_SLOT",
                row_code=row_code,
                slot_number=slot,
                level=1,
                max_stack_level=1,
                max_weight=35000,
                current_weight=0,
                occupied=False,
                active=True,
                accessibility_score=round(
                    0.95 - ((slot - 1) * 0.02),
                    2
                ),
                x_coordinate=55 + (slot * 4),
                y_coordinate=15 + (row_index * 7),
                length=13,
                width=3
            )

            db.add(position)

    # =====================================================
    # PACKAGE STACKS
    # =====================================================

    package_zone = zones["PACK-01"]

    for stack_number in range(1, 13):

        position = StoragePosition(
            zone_id=package_zone.id,
            position_code=(
                f"PACK-{stack_number:03}"
            ),
            position_type="PACKAGE_STACK",
            row_code="P",
            slot_number=stack_number,
            level=1,
            max_stack_level=4,
            max_weight=60000,
            current_weight=0,
            occupied=False,
            active=True,
            accessibility_score=0.75,
            x_coordinate=60 + (stack_number * 2),
            y_coordinate=65,
            length=5,
            width=5,
            height=8
        )

        db.add(position)

    # =====================================================
    # COIL STORAGE
    # =====================================================

    coil_zone = zones["COIL-01"]

    for slot in range(1, 17):

        position = StoragePosition(
            zone_id=coil_zone.id,
            position_code=f"COIL-{slot:03}",
            position_type="COIL_SLOT",
            row_code="C",
            slot_number=slot,
            level=1,
            max_stack_level=1,
            max_weight=40000,
            current_weight=0,
            occupied=False,
            active=True,
            accessibility_score=0.80,
            x_coordinate=35 + (slot * 3),
            y_coordinate=72,
            length=4,
            width=4
        )

        db.add(position)

    # =====================================================
    # BULK SILOS
    # =====================================================

    bulk_zone = zones["BULK-01"]

    for silo_number in range(1, 5):

        position = StoragePosition(
            zone_id=bulk_zone.id,
            position_code=(
                f"SILO-{silo_number:02}"
            ),
            position_type="SILO",
            row_code="SILO",
            slot_number=silo_number,
            level=1,
            max_stack_level=1,
            max_weight=500000,
            current_weight=0,
            occupied=False,
            active=True,
            accessibility_score=0.70,
            x_coordinate=10 + (silo_number * 5),
            y_coordinate=18,
            length=10,
            width=10,
            height=20
        )

        db.add(position)

    db.commit()

    return {
        "status": "INITIALIZED",
        "zones_created": 5,
        "positions_created": 96,
        "structure": {
            "vehicle_slots": 40,
            "container_slots": 24,
            "package_stacks": 12,
            "coil_slots": 16,
            "silos": 4
        }
    }