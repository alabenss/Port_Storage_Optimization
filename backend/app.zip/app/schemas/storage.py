from pydantic import BaseModel
from typing import Optional



class PositionResponse(BaseModel):

    id: int

    position_code: str

    max_weight: float

    current_weight: float

    occupied: bool


    class Config:

        from_attributes = True



class ZoneResponse(BaseModel):

    id: int

    name: str

    zone_type: Optional[str]

    capacity: int


    class Config:

        from_attributes = True



class AllocationResponse(BaseModel):

    id: int

    cargo_id: int

    position_id: int

    status: str


    class Config:

        from_attributes = True