from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.database import get_database

from app.models.cargo_unit import CargoUnit
from app.models.storage_position import StoragePosition
from app.models.movement import Movement
from app.models.allocation import Allocation


router = APIRouter()



# ===============================
# INVENTORY REPORT
# ===============================

@router.get("/inventory")
def inventory_report(
    db: Session = Depends(get_database)
):

    cargo = (

        db.query(CargoUnit)
        .all()

    )


    return [

        {

            "id": c.id,

            "reference": c.reference,

            "weight": c.weight,

            "status": c.status,

            "type": c.cargo_type

        }

        for c in cargo

    ]





# ===============================
# STORAGE REPORT
# ===============================

@router.get("/storage")
def storage_report(

    db: Session = Depends(get_database)

):


    positions = (

        db.query(StoragePosition)
        .all()

    )


    return [

        {

            "position":
                p.position_code,

            "capacity":
                p.max_weight,

            "current_weight":
                p.current_weight,

            "occupied":
                p.occupied


        }

        for p in positions

    ]





# ===============================
# MOVEMENT REPORT
# ===============================

@router.get("/movements")
def movement_report(

    db: Session = Depends(get_database)

):


    movements = (

        db.query(Movement)

        .order_by(
            Movement.created_at.desc()
        )

        .all()

    )


    return [

        {

            "cargo_id":
                m.cargo_id,

            "action":
                m.action,

            "from":
                m.from_position,

            "to":
                m.to_position,

            "date":
                m.created_at


        }

        for m in movements

    ]





# ===============================
# AI REPORT
# ===============================

@router.get("/ai")
def ai_report(

    db: Session = Depends(get_database)

):


    allocations = (

        db.query(Allocation)

        .filter(
            Allocation.allocation_method
            .like("%AI%")
        )

        .all()

    )


    return [

        {

            "cargo":
                a.cargo_id,

            "position":
                a.position_id,

            "weight":
                a.allocated_weight,

            "score":
                a.score,

            "method":
                a.allocation_method


        }

        for a in allocations

    ]