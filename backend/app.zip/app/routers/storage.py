from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_database

from app.models.storage_zone import StorageZone
from app.models.storage_position import StoragePosition
from app.models.vehicle import Vehicle
from app.models.allocation import Allocation
from app.models.movement import Movement
from app.models.cargo_unit import CargoUnit

from app.schemas.storage import (
    ZoneResponse,
    PositionResponse,
    AllocationResponse
)

from app.services.placement_engine import PlacementEngine
from app.services.allocation_service import AllocationService
from app.services.multi_allocation_service import MultiAllocationService
from app.services.relocation_service import RelocationService


router = APIRouter()


# =========================================================
# GET ZONES
# =========================================================

@router.get(
    "/zones",
    response_model=list[ZoneResponse]
)
def get_zones(
    db: Session = Depends(get_database)
):

    return (
        db.query(StorageZone)
        .all()
    )


# =========================================================
# GET POSITIONS
# =========================================================

@router.get(
    "/positions",
    response_model=list[PositionResponse]
)
def get_positions(
    db: Session = Depends(get_database)
):

    return (
        db.query(StoragePosition)
        .all()
    )


# =========================================================
# OCCUPANCY
# =========================================================

@router.get("/occupancy")
def occupancy(
    db: Session = Depends(get_database)
):

    total = (
        db.query(StoragePosition)
        .count()
    )

    occupied = (
        db.query(StoragePosition)
        .filter(
            StoragePosition.occupied == True
        )
        .count()
    )

    return {
        "total_positions": total,
        "occupied": occupied,
        "available": total - occupied,
        "occupancy_percent": round(
            (occupied / total * 100)
            if total
            else 0,
            2
        )
    }


# =========================================================
# VEHICLE ALLOCATION
# =========================================================

@router.post(
    "/allocate/vehicle/{vehicle_id}",
    response_model=AllocationResponse
)
def allocate_vehicle(
    vehicle_id: int,
    db: Session = Depends(get_database)
):

    vehicle = (
        db.query(Vehicle)
        .filter(
            Vehicle.id == vehicle_id
        )
        .first()
    )

    if not vehicle:

        raise HTTPException(
            status_code=404,
            detail="Vehicle not found"
        )

    engine = PlacementEngine()

    position = engine.find_best_position(
        db,
        vehicle
    )

    if not position:

        raise HTTPException(
            status_code=400,
            detail="No available storage position"
        )

    service = AllocationService()

    return service.allocate_vehicle(
        db,
        vehicle,
        position
    )


# =========================================================
# CARGO ALLOCATION
# =========================================================

@router.post(
    "/allocate/cargo/{cargo_id}"
)
def allocate_cargo(
    cargo_id: int,
    db: Session = Depends(get_database)
):

    cargo = (
        db.query(CargoUnit)
        .filter(
            CargoUnit.id == cargo_id
        )
        .first()
    )

    if not cargo:

        raise HTTPException(
            status_code=404,
            detail="Cargo not found"
        )

    service = MultiAllocationService()

    return service.allocate_large_cargo(
        db,
        cargo
    )


# =========================================================
# ALLOCATE USING AI RECOMMENDATION
# =========================================================

@router.post(
    "/allocate/recommended/{cargo_id}"
)
def allocate_recommended_cargo(
    cargo_id: int,
    db: Session = Depends(get_database)
):

    cargo = (
        db.query(CargoUnit)
        .filter(
            CargoUnit.id == cargo_id
        )
        .first()
    )

    if not cargo:

        raise HTTPException(
            status_code=404,
            detail="Cargo not found"
        )

    service = MultiAllocationService()

    return service.allocate_large_cargo(
        db,
        cargo,
    )


# =========================================================
# AI CARGO RELOCATION / RE-OPTIMIZATION
# =========================================================

@router.post(
    "/relocate/cargo/{cargo_id}"
)
def relocate_cargo(
    cargo_id: int,
    db: Session = Depends(get_database)
):

    cargo = (
        db.query(CargoUnit)
        .filter(
            CargoUnit.id == cargo_id
        )
        .first()
    )

    if not cargo:

        raise HTTPException(
            status_code=404,
            detail="Cargo not found"
        )

    service = RelocationService()

    return service.relocate_cargo(
        db,
        cargo
    )


# =========================================================
# RELEASE ONE ALLOCATION
# =========================================================

@router.post(
    "/release/{allocation_id}"
)
def release_allocation(
    allocation_id: int,
    db: Session = Depends(get_database)
):

    allocation = (
        db.query(Allocation)
        .filter(
            Allocation.id == allocation_id
        )
        .first()
    )

    if not allocation:

        raise HTTPException(
            status_code=404,
            detail="Allocation not found"
        )

    service = AllocationService()

    return service.release_allocation(
        db,
        allocation
    )


# =========================================================
# RELEASE ALL STORAGE USED BY ONE CARGO
# =========================================================

@router.post(
    "/release/cargo/{cargo_id}"
)
def release_cargo(
    cargo_id: int,
    db: Session = Depends(get_database)
):

    cargo = (
        db.query(CargoUnit)
        .filter(
            CargoUnit.id == cargo_id
        )
        .first()
    )

    if not cargo:

        raise HTTPException(
            status_code=404,
            detail="Cargo not found"
        )

    allocations = (
        db.query(Allocation)
        .filter(
            Allocation.cargo_id == cargo_id,
            Allocation.status == "ACTIVE"
        )
        .all()
    )

    if not allocations:

        return {
            "status": "NOT_ALLOCATED",
            "cargo_id": cargo.id,
            "reference": cargo.reference,
            "released_positions": []
        }

    released_positions = []

    try:

        for allocation in allocations:

            position = allocation.position

            if position:

                released_positions.append(
                    position.position_code
                )

                movement = Movement(
                    cargo_id=cargo.id,
                    from_position=position.position_code,
                    to_position=None,
                    action="RELEASED",
                    reason=(
                        f"Cargo {cargo.reference} released "
                        f"from {position.position_code}"
                    ),
                    performed_by="SYSTEM"
                )

                db.add(movement)

                position.occupied = False
                position.current_weight = 0

            allocation.status = "RELEASED"
            allocation.released_at = datetime.utcnow()

        cargo.status = "RELEASED"

        db.commit()

    except Exception:

        db.rollback()
        raise

    return {
        "status": "CARGO_RELEASED",
        "cargo_id": cargo.id,
        "reference": cargo.reference,
        "released_allocations": len(allocations),
        "released_positions": released_positions,
        "cargo_status": cargo.status
    }


# =========================================================
# MOVEMENTS
# =========================================================

@router.get(
    "/movements"
)
def movements(
    db: Session = Depends(get_database)
):

    return (
        db.query(Movement)
        .order_by(
            Movement.created_at.desc()
        )
        .all()
    )


# =========================================================
# RESET TEST STORAGE
# =========================================================

@router.delete(
    "/reset-test-storage"
)
def reset_test_storage(
    db: Session = Depends(get_database)
):

    db.query(Allocation).delete()

    positions = (
        db.query(StoragePosition)
        .all()
    )

    for position in positions:

        position.occupied = False
        position.current_weight = 0

    db.commit()

    return {
        "status": "STORAGE_RESET"
    }