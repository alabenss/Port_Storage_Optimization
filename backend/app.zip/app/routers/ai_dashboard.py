from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.database import get_database

from app.models.allocation import Allocation
from app.models.movement import Movement
from app.models.cargo_unit import CargoUnit


router = APIRouter()



# =====================================================
# AI DASHBOARD
# =====================================================

@router.get("/ai")
def ai_dashboard(
    db: Session = Depends(get_database)
):


    # --------------------------------
    # AI RECOMMENDATIONS
    # --------------------------------

    total_recommendations = (
        db.query(Allocation)
        .filter(
            Allocation.allocation_method
            == "AI_RECOMMENDED"
        )
        .count()
    )



    # --------------------------------
    # ALLOCATION TYPES
    # --------------------------------

    multi_position = (
        db.query(Allocation.cargo_id)
        .group_by(
            Allocation.cargo_id
        )
        .having(
            func.count(
                Allocation.id
            ) > 1
        )
        .count()
    )


    single_position = (
        db.query(Allocation.cargo_id)
        .group_by(
            Allocation.cargo_id
        )
        .having(
            func.count(
                Allocation.id
            ) == 1
        )
        .count()
    )



    # --------------------------------
    # RELOCATIONS
    # --------------------------------

    successful_relocations = (
        db.query(Movement)
        .filter(
            Movement.action
            == "RELOCATED"
        )
        .count()
    )


    failed_relocations = 0



    # --------------------------------
    # RISK LEVELS
    # FROM ALLOCATION SCORE
    # --------------------------------

    high = (
        db.query(Allocation)
        .filter(
            Allocation.score < 120
        )
        .count()
    )


    medium = (
        db.query(Allocation)
        .filter(
            Allocation.score >= 120,
            Allocation.score < 150
        )
        .count()
    )


    low = (
        db.query(Allocation)
        .filter(
            Allocation.score >= 150
        )
        .count()
    )



    # --------------------------------
    # RECENT AI DECISIONS
    # --------------------------------

    recent = (
        db.query(Allocation)
        .order_by(
            Allocation.allocated_at.desc()
        )
        .limit(10)
        .all()
    )


    decisions = []


    for allocation in recent:

        decisions.append({

            "cargo_id":
                allocation.cargo_id,

            "position":
                allocation.position_id,

            "weight":
                allocation.allocated_weight,

            "method":
                allocation.allocation_method,

            "score":
                allocation.score

        })



    return {


        "ai_engine": {

            "status":
                "ACTIVE",

            "recommendations":
                total_recommendations

        },



        "allocation_strategy": {

            "single_position":
                single_position,

            "multi_position":
                multi_position

        },



        "relocations": {

            "successful":
                successful_relocations,

            "failed":
                failed_relocations

        },



        "risk_analysis": {

            "HIGH":
                high,

            "MEDIUM":
                medium,

            "LOW":
                low

        },



        "recent_decisions":
            decisions

    }