import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";

import "./App.css";


import {
  BrowserRouter
} from "react-router-dom";


import {
  AuthProvider
} from "./context/AuthContext";


import {
  ModalProvider
} from "./context/ModalContext";

import "leaflet/dist/leaflet.css";

ReactDOM.createRoot(
  document.getElementById("root")
)
.render(

<React.StrictMode>

<ModalProvider>

<AuthProvider>

<BrowserRouter>

<App />

</BrowserRouter>

</AuthProvider>

</ModalProvider>


</React.StrictMode>


);